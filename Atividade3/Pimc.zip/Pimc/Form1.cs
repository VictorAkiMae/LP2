﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MskbxIMC_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPesoAtual.Clear();
            mskbxIMC.Clear();        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void MskbxPesoAtual_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskbxPesoAtual, "");

            if (!double.TryParse(mskbxPesoAtual.Text, out peso) || (peso <= 0))
            {
                MessageBox.Show("Peso invalido");
                errorProvider1.SetError(mskbxPesoAtual, "peso invalido ");
            }
        }

        private void MskbxAltura_Validated(object sender, EventArgs e)
        {
            double altura;
            errorProvider1.SetError(mskbxAltura, "");

            if (!double.TryParse(mskbxAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura invalido");
                errorProvider1.SetError(mskbxAltura, "Altura invalido ");
            }
        }

        private void MskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double pesoAtual, altura, imc=0;

            if (Double.TryParse(mskbxAltura.Text, out altura) && Double.TryParse(mskbxPesoAtual.Text, out pesoAtual) )
            {

                if ((altura<=0) || (pesoAtual<=0))
                    MessageBox.Show("Valores devem ser maiores do que 0");
                else 
                    imc = pesoAtual / Math.Pow(altura,1 );
                    imc = Math.Round(imc, 1);
               

                if (imc < 18.5 )
                  MessageBox.Show("classificação : magreza ") ;
                else if (imc <= 24.9)
                    MessageBox.Show("Normal");
                else if (imc <= 29.9)
                    MessageBox.Show("Sobrepeso");
                else if (imc <= 39.9)
                    MessageBox.Show("Obesidade");
                else
                    MessageBox.Show("Obesidade Grave");

            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {

        }
    }
}
