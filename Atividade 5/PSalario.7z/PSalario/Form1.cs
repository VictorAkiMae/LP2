﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double salBruto, Aliquota , DescontoINSS ;
        public Form1()
        {
            InitializeComponent();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void MskSalBruto_Validated(object sender, EventArgs e)
        {
          
        }

        private void TxtNomeFunc_Validated(object sender, EventArgs e)
        {
          
                


        }

        private void BtnVericarDesc_Click(object sender, EventArgs e)
        {
            if (salBruto <= 800.47)
            {
                txtAliquotaINSS.Text = "7,65";
                DescontoINSS = 0.0765 * salBruto;
            }
            else if (salBruto <= 1050.00)
                  {
                   txtAliquotaINSS.Text = "8,65";
                   DescontoINSS = ((8.65 / 100) * salBruto);
                   }
                  else if (salBruto <- 1400.77)
                       {
                        txtAliquotaINSS.Text = "9.00";
                        DescontoINSS = 
                       }
        }

        private void MskbxSalBruto_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxSalBruto.Text, out salBruto) && (salBruto > 0)){
                MessageBox.Show("Digite um valor válido");
                mskbxSalBruto.Focus();
            }
                
        }

        private void TxtAliquotaINSS_Validated(object sender, EventArgs e)
        {

        }

        private void MskbxNomeFUnc_Validated(object sender, EventArgs e)
        {
            if (true)
            {

            }
        }
    }
}
