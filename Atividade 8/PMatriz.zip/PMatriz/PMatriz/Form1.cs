﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;


namespace PMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";


            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um n° para a posição : {i+ 1} ");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
                foreach (int i in vetor)
                    auxiliar += 1+"\n";
            MessageBox.Show(auxiliar);
        }

        private void BtnExercicio2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double media = 0;
            int i = 0;
            string auxiliar = "";

            for (int aluno = 0; aluno < 5; aluno++)
            {
                for (int notaP = 0; notaP < 3; notaP++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota para a posição : {i + 1} ");
                    if (!double.TryParse(auxiliar, out notas[aluno, notaP]))
                    {
                        MessageBox.Show("Nota inválida");
                        notaP--;
                    }
                    else
                    {
                        media = (media + notas[aluno, notaP]);
                    }
                }
                media = media / 3;
            }
            MessageBox.Show($"Media do aluno: {i + 1}" + media.ToString());
            //imprimir stringona md1 + md2 + ... md20

        }
        }
}
