﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, numero3, resultado; //globais , valor zero 
        public Form1()
        {
            InitializeComponent();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtNum3.Text = resultado.ToString();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("não pode dividir por zero!!!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtNum3.Text = resultado.ToString();
            }

        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("número inválido!");
                txtNum1.Focus(); // volta para receber numero 1 
            }
        }

        private void TxtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("número inválido!");
                txtNum2.Focus();
            }
        }

        private void TxtNum3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button6_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtNum3.Text = resultado.ToString();
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtNum3.Text = resultado.ToString();
        }

        private void Btn_Validated(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair mesmo?","Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
            {

            }
        }

        private void TxtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();

            txtNum1.Focus(); //volta p o 1° , interessante voltar, obriga  a colocar dados
            resultado = 0;
            numero1 = 0,
            numero2 = 0;
        }
    }
}
